//
//  SVGPolygonElement.h
//  SVGKit
//
//  Copyright Matt Rajca 2011. All rights reserved.
//

#import <SVGKit/BaseClassForAllSVGBasicShapes.h>
#import <SVGKit/BaseClassForAllSVGBasicShapes_ForSubclasses.h>

@interface SVGPolygonElement : BaseClassForAllSVGBasicShapes { }

@end
