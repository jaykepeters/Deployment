#import <SVGKit/BaseClassForAllSVGBasicShapes.h>
#import <SVGKit/BaseClassForAllSVGBasicShapes_ForSubclasses.h>

@interface SVGPolylineElement : BaseClassForAllSVGBasicShapes { }

@end
