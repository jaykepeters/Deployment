#import <Foundation/Foundation.h>

#import <SVGKit/SVGKParser.h>

@interface SVGKParserSVG : NSObject <SVGKParserExtension> {
}

@end
