/*
 http://www.w3.org/TR/SVG/struct.html#InterfaceSVGDefsElement
 
 */
#import <SVGKit/SVGElement.h>

@interface SVGDefsElement : SVGElement { }

@end
